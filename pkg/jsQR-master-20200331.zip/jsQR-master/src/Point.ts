export interface Point {
  x: number;
  y: number;
}
